import React from "react";

function Notfound() {
  return (
    <>
      <section
        id="about"
        className="d-flex align-items-center justify-content-center text-center py-5"
      >
        <div className="container">
          <img src="404-error.jpg" alt="Error 404" />
        </div>
      </section>
    </>
  );
}

export default Notfound;
